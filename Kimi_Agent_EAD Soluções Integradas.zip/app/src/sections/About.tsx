import { useEffect, useRef, useState } from 'react';
import { Award, Users, Clock, Shield } from 'lucide-react';

const About = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [counters, setCounters] = useState({ years: 0, clients: 0, support: 0 });

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    const duration = 2000;
    const steps = 60;
    const interval = duration / steps;

    const targets = { years: 10, clients: 500, support: 24 };
    let step = 0;

    const timer = setInterval(() => {
      step++;
      const progress = step / steps;
      const easeOut = 1 - Math.pow(1 - progress, 3);

      setCounters({
        years: Math.round(targets.years * easeOut),
        clients: Math.round(targets.clients * easeOut),
        support: Math.round(targets.support * easeOut),
      });

      if (step >= steps) {
        clearInterval(timer);
      }
    }, interval);

    return () => clearInterval(timer);
  }, [isVisible]);

  const stats = [
    { icon: Award, value: counters.years, suffix: '+', label: 'Anos de Experiência' },
    { icon: Users, value: counters.clients, suffix: '+', label: 'Clientes Atendidos' },
    { icon: Clock, value: counters.support, suffix: '/7', label: 'Monitoramento' },
  ];

  const differentials = [
    {
      title: 'Monitoramento 24h',
      description: 'Central própria para vigilância contínua e resposta imediata.',
    },
    {
      title: 'Deslocamento Móvel',
      description: 'Unidades equipadas para atender com agilidade e eficiência.',
    },
    {
      title: 'Prevenção Ativa',
      description: 'Monitoramento de imagens que reforça a segurança e minimiza riscos.',
    },
    {
      title: 'Manutenção Especializada',
      description: 'Profissionais prontos para garantir o pleno funcionamento.',
    },
  ];

  return (
    <section
      id="about"
      ref={sectionRef}
      className="section-padding bg-dark relative overflow-hidden"
    >
      {/* Background Decoration */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-radial opacity-30" />

      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image */}
          <div
            className={`relative transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
            }`}
          >
            <div className="relative aspect-[4/5] rounded-2xl overflow-hidden">
              {/* Glow Effect */}
              <div className="absolute -inset-4 bg-gradient-to-br from-yellow-brand/20 to-orange-brand/20 rounded-3xl blur-2xl opacity-40" />
              
              <img
                src="/about-security.jpg"
                alt="Sobre a EAD Segurança"
                className="relative w-full h-full object-cover rounded-2xl"
              />
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-dark/40 via-transparent to-transparent" />
            </div>

            {/* Stats Cards */}
            <div className="absolute -bottom-6 -right-6 lg:-right-12 glass rounded-xl p-6 border border-white/10 shadow-xl">
              <div className="grid grid-cols-3 gap-6">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <stat.icon className="w-6 h-6 text-yellow-brand mx-auto mb-2" />
                    <div className="text-2xl font-display font-bold text-white">
                      {stat.value}{stat.suffix}
                    </div>
                    <div className="text-xs text-gray-400">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="space-y-8 lg:pl-8">
            {/* Label */}
            <div
              className={`transition-all duration-700 delay-200 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              <span className="label">Quem Somos</span>
            </div>

            {/* Headline */}
            <h2
              className={`heading-lg text-white transition-all duration-700 delay-300 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              EAD <span className="text-gradient">Soluções Integradas</span>
            </h2>

            {/* Description */}
            <div
              className={`space-y-4 transition-all duration-700 delay-400 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              <p className="text-body">
                A EAD é uma empresa renomada no segmento de terceirização, especializada 
                em áreas como Segurança Eletrônica, CFTV Digital, Portarias e Limpeza. 
                Nossa equipe é formada por profissionais altamente qualificados, 
                comprometidos em oferecer soluções eficientes e confiáveis.
              </p>
              <p className="text-body">
                Com anos de experiência no mercado, a EAD Soluções Integradas foi fundada com um 
                propósito claro: não ser apenas mais uma empresa, mas a maior referência 
                na área. Acreditamos que ninguém tem a chance de viver duas vezes para 
                fazer diferente, por isso, escolhemos fazer o melhor sempre.
              </p>
            </div>

            {/* Differentials Grid */}
            <div
              className={`grid sm:grid-cols-2 gap-4 transition-all duration-700 delay-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              {differentials.map((item, index) => (
                <div
                  key={index}
                  className="p-4 rounded-lg bg-white/5 border border-white/10 hover:border-yellow-brand/30 transition-all duration-300 hover:-translate-y-1"
                >
                  <Shield className="w-5 h-5 text-yellow-brand mb-2" />
                  <h4 className="font-display font-semibold text-white text-sm mb-1">
                    {item.title}
                  </h4>
                  <p className="text-xs text-gray-400">{item.description}</p>
                </div>
              ))}
            </div>

            {/* Signature */}
            <div
              className={`pt-4 transition-all duration-700 delay-600 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-yellow-brand/20 flex items-center justify-center">
                  <span className="font-display font-bold text-yellow-brand">AP</span>
                </div>
                <div>
                  <div className="font-display font-semibold text-white">Abmael Pedroza</div>
                  <div className="text-sm text-gray-400">CEO & Founder</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
