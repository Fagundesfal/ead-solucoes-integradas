import { useEffect, useRef } from 'react';
import { ArrowRight, Phone, Instagram, Shield, Lock, Camera, Eye, Bell } from 'lucide-react';

const Hero = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!contentRef.current) return;
      const scrollY = window.scrollY;
      const parallaxValue = scrollY * 0.3;
      contentRef.current.style.transform = `translateY(${parallaxValue}px)`;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const floatingIcons = [
    { Icon: Shield, className: 'top-20 left-[10%] animation-delay-100', size: 32 },
    { Icon: Lock, className: 'top-32 right-[15%] animation-delay-300', size: 28 },
    { Icon: Camera, className: 'bottom-40 left-[8%] animation-delay-500', size: 24 },
    { Icon: Eye, className: 'top-40 right-[8%] animation-delay-200', size: 26 },
    { Icon: Bell, className: 'bottom-32 right-[12%] animation-delay-400', size: 22 },
  ];

  return (
    <section
      id="home"
      ref={heroRef}
      className="relative min-h-screen flex items-center overflow-hidden bg-dark"
    >
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-radial opacity-50" />
      
      {/* Animated Background Gradient */}
      <div 
        className="absolute inset-0 opacity-30"
        style={{
          background: 'radial-gradient(ellipse at 30% 50%, rgba(245, 197, 24, 0.15) 0%, transparent 50%), radial-gradient(ellipse at 70% 80%, rgba(230, 126, 34, 0.1) 0%, transparent 40%)',
        }}
      />

      {/* Floating Icons */}
      {floatingIcons.map(({ Icon, className, size }, index) => (
        <div
          key={index}
          className={`absolute ${className} text-yellow-brand/20 animate-float hidden lg:block`}
          style={{ animationDelay: `${index * 0.5}s` }}
        >
          <Icon size={size} />
        </div>
      ))}

      <div className="container-custom relative z-10 pt-24">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <div ref={contentRef} className="space-y-8">
            {/* Label */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 animate-fade-in">
              <Shield className="w-4 h-4 text-yellow-brand" />
              <span className="text-sm font-medium text-gray-300">
                Segurança de Ponta
              </span>
            </div>

            {/* Headline */}
            <h1 className="heading-xl text-white animate-slide-up">
              SEGURANÇA E{' '}
              <span className="text-gradient">TECNOLOGIA</span>
            </h1>

            {/* Subheadline */}
            <p className="text-xl md:text-2xl font-display text-gray-200 animate-slide-up animation-delay-200">
              Segurança significa preservar sua vida e seus negócios
            </p>

            {/* Description */}
            <p className="text-body max-w-lg animate-slide-up animation-delay-300">
              Para isso, usamos tecnologia de ponta e agentes experientes em
              diferentes frentes de segurança. Proteja o que é seu com quem entende do assunto.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap gap-4 animate-slide-up animation-delay-400">
              <button
                onClick={() => scrollToSection('#services')}
                className="btn-primary flex items-center gap-2 group"
              >
                Conheça Nossos Serviços
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
              <button
                onClick={() => scrollToSection('#contact')}
                className="btn-outline"
              >
                Fale Conosco
              </button>
            </div>

            {/* Contact Info */}
            <div className="flex flex-wrap gap-6 pt-4 animate-slide-up animation-delay-500">
              <a
                href="tel:11993205614"
                className="flex items-center gap-2 text-gray-400 hover:text-yellow-brand transition-colors"
              >
                <Phone className="w-5 h-5" />
                <span>(11) 99320-5614</span>
              </a>
              <a
                href="https://instagram.com/ead_segurancaetecnologia"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-gray-400 hover:text-yellow-brand transition-colors"
              >
                <Instagram className="w-5 h-5" />
                <span>@ead_segurancaetecnologia</span>
              </a>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative animate-scale-in animation-delay-300">
            <div className="relative aspect-[4/5] lg:aspect-[3/4] rounded-2xl overflow-hidden">
              {/* Glow Effect */}
              <div className="absolute -inset-4 bg-gradient-to-r from-yellow-brand/20 to-orange-brand/20 rounded-3xl blur-2xl opacity-60" />
              
              {/* Image */}
              <img
                src="/hero-building.jpg"
                alt="Fachada Corporativa EAD Soluções Integradas"
                className="relative w-full h-full object-cover rounded-2xl"
              />
              
              {/* Overlay Gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-dark/60 via-transparent to-transparent" />
              
              {/* Stats Card */}
              <div className="absolute bottom-6 left-6 right-6 glass rounded-xl p-4 border border-white/10">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-display font-bold text-yellow-brand">10+</div>
                    <div className="text-xs text-gray-400">Anos</div>
                  </div>
                  <div>
                    <div className="text-2xl font-display font-bold text-yellow-brand">500+</div>
                    <div className="text-xs text-gray-400">Clientes</div>
                  </div>
                  <div>
                    <div className="text-2xl font-display font-bold text-yellow-brand">24/7</div>
                    <div className="text-xs text-gray-400">Monitoramento</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-dark to-transparent" />
    </section>
  );
};

export default Hero;
