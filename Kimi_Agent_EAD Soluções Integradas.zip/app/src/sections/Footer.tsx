import { Shield, Phone, MapPin, Instagram, Mail, ArrowUp } from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Sobre', href: '#about' },
    { label: 'Serviços', href: '#services' },
    { label: 'Contato', href: '#contact' },
  ];

  const serviceLinks = [
    'Monitoramento 24h',
    'CFTV',
    'Portaria',
    'Pós-Obra',
    'Limpeza',
  ];

  return (
    <footer className="bg-dark-light relative overflow-hidden">
      {/* Top Border Animation */}
      <div className="absolute top-0 left-0 right-0 h-px">
        <div 
          className="h-full w-full animate-gradient-shift"
          style={{
            background: 'linear-gradient(90deg, transparent, #f5c518, #e67e22, #f5c518, transparent)',
            backgroundSize: '200% 100%',
          }}
        />
      </div>

      {/* Main Footer */}
      <div className="container-custom py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <a href="#home" onClick={(e) => { e.preventDefault(); scrollToSection('#home'); }} className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-lg bg-yellow-brand flex items-center justify-center">
                <Shield className="w-7 h-7 text-dark" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-xl text-white">EAD</span>
                <span className="font-display text-[10px] tracking-wider text-yellow-brand">Soluções Integradas</span>
              </div>
            </a>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              Segurança significa preservar sua vida e seus negócios. 
              Tecnologia de ponta e agentes experientes.
            </p>
            <div className="flex items-center gap-4">
              <a
                href="https://instagram.com/ead_segurancaetecnologia"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-gray-400 hover:bg-yellow-brand hover:text-dark transition-all duration-300"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="mailto:contato@eadseguranca.com.br"
                className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-gray-400 hover:bg-yellow-brand hover:text-dark transition-all duration-300"
              >
                <Mail className="w-5 h-5" />
              </a>
              <a
                href="tel:11994293041"
                className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-gray-400 hover:bg-yellow-brand hover:text-dark transition-all duration-300"
              >
                <Phone className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-display font-semibold text-white mb-6">Navegação</h4>
            <ul className="space-y-3">
              {navLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection(link.href);
                    }}
                    className="text-gray-400 hover:text-yellow-brand transition-colors duration-300 text-sm"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-display font-semibold text-white mb-6">Serviços</h4>
            <ul className="space-y-3">
              {serviceLinks.map((service) => (
                <li key={service}>
                  <span className="text-gray-400 text-sm">{service}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display font-semibold text-white mb-6">Contato</h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="tel:11994293041"
                  className="flex items-center gap-3 text-gray-400 hover:text-yellow-brand transition-colors duration-300"
                >
                  <Phone className="w-4 h-4" />
                  <span className="text-sm">(11) 99429-3041</span>
                </a>
              </li>
              <li>
                <div className="flex items-start gap-3 text-gray-400">
                  <MapPin className="w-4 h-4 mt-0.5" />
                  <span className="text-sm">
                    Av. Carmine Gragnano, 150<br />
                    Centro - Jandira, SP
                  </span>
                </div>
              </li>
              <li>
                <a
                  href="https://instagram.com/ead_segurancaetecnologia"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 text-gray-400 hover:text-yellow-brand transition-colors duration-300"
                >
                  <Instagram className="w-4 h-4" />
                  <span className="text-sm">@ead_segurancaetecnologia</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="container-custom py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-gray-500 text-sm text-center md:text-left">
              © {new Date().getFullYear()} EAD Soluções Integradas. Todos os direitos reservados.
            </p>
            <div className="flex items-center gap-6">
              <span className="text-gray-500 text-sm hover:text-yellow-brand cursor-pointer transition-colors">
                Política de Privacidade
              </span>
              <span className="text-gray-500 text-sm hover:text-yellow-brand cursor-pointer transition-colors">
                Termos de Uso
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll to Top Button */}
      <button
        onClick={scrollToTop}
        className="fixed bottom-8 right-8 w-12 h-12 rounded-full bg-yellow-brand text-dark flex items-center justify-center shadow-glow hover:shadow-glow-lg transition-all duration-300 hover:scale-110 z-50"
        aria-label="Voltar ao topo"
      >
        <ArrowUp className="w-5 h-5" />
      </button>
    </footer>
  );
};

export default Footer;
