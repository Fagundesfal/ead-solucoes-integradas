import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Monitor, Video, DoorOpen, Sparkles, Brush } from 'lucide-react';

const Services = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const services = [
    {
      id: 1,
      title: 'Monitoramento de Alarme 24h',
      description: 'Proteção contínua com resposta rápida para garantir a segurança do seu patrimônio a qualquer hora.',
      image: '/service-monitoring.jpg',
      icon: Monitor,
      features: ['Central própria', 'Resposta imediata', 'Equipe especializada'],
    },
    {
      id: 2,
      title: 'CFTV',
      description: 'Monitoramento inteligente com imagens em tempo real para garantir segurança e controle do ambiente.',
      image: '/service-cftv.jpg',
      icon: Video,
      features: ['Imagens HD', 'Acesso remoto', 'Gravação contínua'],
    },
    {
      id: 3,
      title: 'Portaria',
      description: 'Gestão de acesso com profissionais capacitados e tecnologias avançadas para garantir segurança.',
      image: '/service-portaria.jpg',
      icon: DoorOpen,
      features: ['Controle de acesso', 'Registro de visitantes', 'Segurança 24h'],
    },
    {
      id: 4,
      title: 'Pós-Obra',
      description: 'Serviço especializado em limpeza e organização, deixando o ambiente pronto para uso.',
      image: '/service-posobra.jpg',
      icon: Sparkles,
      features: ['Limpeza profunda', 'Remoção de resíduos', 'Ambiente pronto'],
    },
    {
      id: 5,
      title: 'Limpeza',
      description: 'Higienização profissional para garantir ambientes limpos, saudáveis e bem cuidados.',
      image: '/service-limpeza.jpg',
      icon: Brush,
      features: ['Equipe treinada', 'Produtos adequados', 'Rotina flexível'],
    },
  ];

  return (
    <section
      id="services"
      ref={sectionRef}
      className="section-padding bg-dark relative overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-radial opacity-20" />

      <div className="container-custom relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span
            className={`label inline-block mb-4 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            Nossos Serviços
          </span>
          <h2
            className={`heading-lg text-white mb-6 transition-all duration-700 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            Soluções Completas em{' '}
            <span className="text-gradient">Segurança</span>
          </h2>
          <p
            className={`text-body transition-all duration-700 delay-200 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            Oferecemos sistemas avançados de controle de acesso, monitorando a entrada 
            e saída de pessoas e veículos em empresas ou condomínios.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div
              key={service.id}
              className={`group relative bg-dark-light rounded-2xl overflow-hidden border border-white/10 hover:border-yellow-brand/30 transition-all duration-500 card-hover ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
              }`}
              style={{ transitionDelay: `${300 + index * 100}ms` }}
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark-light via-dark-light/50 to-transparent" />
                
                {/* Service Number */}
                <div className="absolute top-4 left-4 w-10 h-10 rounded-full bg-yellow-brand flex items-center justify-center">
                  <span className="font-display font-bold text-dark">{service.id}</span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <service.icon className="w-5 h-5 text-yellow-brand" />
                  <h3 className="font-display font-semibold text-white text-lg">
                    {service.title}
                  </h3>
                </div>
                
                <p className="text-gray-400 text-sm mb-4">
                  {service.description}
                </p>

                {/* Features */}
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-xs text-gray-500">
                      <div className="w-1.5 h-1.5 rounded-full bg-yellow-brand" />
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <button className="flex items-center gap-2 text-sm font-medium text-yellow-brand hover:text-white transition-colors group/btn">
                  Saiba mais
                  <ArrowRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div
          className={`text-center mt-12 transition-all duration-700 delay-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <p className="text-gray-400 mb-4">
            Precisa de uma solução personalizada?
          </p>
          <a
            href="#contact"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="btn-primary inline-flex items-center gap-2"
          >
            Fale com um Especialista
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Services;
