import { useEffect, useRef, useState } from 'react';
import { Radio, Truck, Eye, Wrench } from 'lucide-react';

const Features = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    {
      icon: Radio,
      title: 'Monitoramento 24h',
      description: 'Central própria para vigilância contínua e resposta imediata a qualquer incidente.',
      color: 'from-yellow-brand/20 to-orange-brand/20',
    },
    {
      icon: Truck,
      title: 'Deslocamento Móvel',
      description: 'Unidades equipadas para atender com agilidade e eficiência quando necessário.',
      color: 'from-orange-brand/20 to-red-500/20',
    },
    {
      icon: Eye,
      title: 'Prevenção Ativa',
      description: 'Monitoramento de imagens que reforça a segurança e minimiza riscos em caso de sinistros.',
      color: 'from-green-500/20 to-emerald-500/20',
    },
    {
      icon: Wrench,
      title: 'Manutenção Especializada',
      description: 'Profissionais prontos para garantir o pleno funcionamento dos equipamentos.',
      color: 'from-blue-500/20 to-cyan-500/20',
    },
  ];

  return (
    <section
      ref={sectionRef}
      className="section-padding bg-dark relative overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial opacity-30" />
      </div>

      <div className="container-custom relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span
            className={`label inline-block mb-4 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            Diferenciais
          </span>
          <h2
            className={`heading-lg text-white transition-all duration-700 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            Por Que Escolher a{' '}
            <span className="text-gradient">EAD?</span>
          </h2>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className={`group relative p-8 rounded-2xl bg-dark-light border border-white/10 hover:border-yellow-brand/30 transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
              }`}
              style={{ 
                transitionDelay: `${200 + index * 150}ms`,
                transform: isVisible ? `translateY(${index % 2 === 0 ? '0' : '20px'})` : 'translateY(48px)'
              }}
            >
              {/* Background Gradient */}
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
              
              {/* Content */}
              <div className="relative z-10">
                {/* Icon */}
                <div className="w-14 h-14 rounded-xl bg-yellow-brand/10 flex items-center justify-center mb-6 group-hover:bg-yellow-brand/20 transition-colors duration-300">
                  <feature.icon className="w-7 h-7 text-yellow-brand animate-spin-slow" style={{ animationDuration: '20s' }} />
                </div>

                {/* Title */}
                <h3 className="font-display font-semibold text-white text-xl mb-3">
                  {feature.title}
                </h3>

                {/* Description */}
                <p className="text-gray-400 leading-relaxed">
                  {feature.description}
                </p>
              </div>

              {/* Corner Decoration */}
              <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-yellow-brand/20 rounded-tr-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="absolute bottom-4 left-4 w-8 h-8 border-b-2 border-l-2 border-yellow-brand/20 rounded-bl-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
          ))}
        </div>

        {/* Bottom Text */}
        <div
          className={`mt-16 text-center transition-all duration-700 delay-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <p className="text-gray-400 max-w-2xl mx-auto">
            Nossos diferenciais nos tornam a escolha ideal para quem busca 
            segurança de verdade. Cada detalhe é pensado para oferecer o melhor 
            serviço aos nossos clientes.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Features;
