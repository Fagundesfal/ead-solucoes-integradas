import { useEffect, useRef, useState } from 'react';
import { Eye, Target, Heart, Trophy } from 'lucide-react';

const Pillars = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const pillars = [
    {
      number: '01',
      icon: Eye,
      title: 'Visão',
      description: 'Ser a maior referência em segurança, reconhecida pela excelência, inovação e compromisso em proteger o que realmente importa para nossos clientes.',
    },
    {
      number: '02',
      icon: Target,
      title: 'Missão',
      description: 'Proteger pessoas e negócios com soluções inovadoras, tecnologia de ponta e uma equipe dedicada, garantindo segurança, confiança e tranquilidade.',
    },
    {
      number: '03',
      icon: Heart,
      title: 'Valores',
      description: 'Excelência, Inovação, Confiança, Compromisso e Respeito. São esses valores que guiam cada ação da nossa empresa.',
    },
    {
      number: '04',
      icon: Trophy,
      title: 'Grandeza',
      description: 'Alcançar excelência e liderança no setor, sendo reconhecida pela inovação, qualidade e impacto positivo na vida de nossos clientes.',
    },
  ];

  return (
    <section
      ref={sectionRef}
      className="section-padding bg-dark relative overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-yellow-brand/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-orange-brand/5 rounded-full blur-3xl" />
      </div>

      <div className="container-custom relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span
            className={`label inline-block mb-4 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            Nossa Fundação
          </span>
          <h2
            className={`heading-lg text-white mb-6 transition-all duration-700 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            Nossos Pilares de{' '}
            <span className="text-gradient">Sucesso</span>
          </h2>
          <p
            className={`text-body transition-all duration-700 delay-200 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
          >
            Fundamentos que guiam nossa excelência e nos mantêm focados em entregar 
            o melhor para nossos clientes.
          </p>
        </div>

        {/* Pillars Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {pillars.map((pillar, index) => (
            <div
              key={index}
              className={`group relative transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
              }`}
              style={{ transitionDelay: `${300 + index * 150}ms` }}
            >
              <div className="relative p-8 rounded-2xl bg-dark-light border border-white/10 hover:border-yellow-brand/30 transition-all duration-500 h-full card-hover">
                {/* Number */}
                <div className="absolute -top-4 -left-2 font-display text-6xl font-bold text-yellow-brand/10 group-hover:text-yellow-brand/20 transition-colors duration-300">
                  {pillar.number}
                </div>

                {/* Content */}
                <div className="relative z-10">
                  {/* Icon */}
                  <div className="w-12 h-12 rounded-lg bg-yellow-brand/10 flex items-center justify-center mb-6 group-hover:bg-yellow-brand/20 transition-colors duration-300">
                    <pillar.icon className="w-6 h-6 text-yellow-brand" />
                  </div>

                  {/* Title */}
                  <h3 className="font-display font-semibold text-white text-xl mb-4">
                    {pillar.title}
                  </h3>

                  {/* Description */}
                  <p className="text-gray-400 text-sm leading-relaxed">
                    {pillar.description}
                  </p>
                </div>

                {/* Hover Line */}
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-yellow-brand group-hover:w-1/2 transition-all duration-500" />
              </div>
            </div>
          ))}
        </div>

        {/* Quote */}
        <div
          className={`mt-16 text-center transition-all duration-700 delay-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          }`}
        >
          <blockquote className="relative inline-block">
            <div className="absolute -top-4 -left-8 text-6xl text-yellow-brand/20 font-display">"</div>
            <p className="text-xl md:text-2xl font-display text-white italic max-w-3xl mx-auto">
              Ninguém tem a chance de viver duas vezes para fazer diferente, 
              por isso, escolhemos fazer o melhor sempre.
            </p>
            <div className="absolute -bottom-8 -right-8 text-6xl text-yellow-brand/20 font-display">"</div>
          </blockquote>
          <div className="mt-8">
            <span className="text-yellow-brand font-display">Abmael Pedroza</span>
            <span className="text-gray-500 text-sm ml-2">- CEO & Founder</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pillars;
