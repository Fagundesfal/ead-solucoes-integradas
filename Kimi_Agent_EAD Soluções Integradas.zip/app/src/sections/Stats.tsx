import { useEffect, useRef, useState } from 'react';
import { Calendar, Users, UserCheck, Clock } from 'lucide-react';

const Stats = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [counters, setCounters] = useState({
    years: 0,
    clients: 0,
    professionals: 0,
    hours: 0,
  });

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    const duration = 2500;
    const steps = 60;
    const interval = duration / steps;

    const targets = {
      years: 10,
      clients: 500,
      professionals: 50,
      hours: 24,
    };

    let step = 0;

    const timer = setInterval(() => {
      step++;
      const progress = step / steps;
      const easeOut = 1 - Math.pow(1 - progress, 3);

      setCounters({
        years: Math.round(targets.years * easeOut),
        clients: Math.round(targets.clients * easeOut),
        professionals: Math.round(targets.professionals * easeOut),
        hours: Math.round(targets.hours * easeOut),
      });

      if (step >= steps) {
        clearInterval(timer);
      }
    }, interval);

    return () => clearInterval(timer);
  }, [isVisible]);

  const stats = [
    {
      icon: Calendar,
      value: counters.years,
      suffix: '+',
      label: 'Anos de Experiência',
    },
    {
      icon: Users,
      value: counters.clients,
      suffix: '+',
      label: 'Clientes Atendidos',
    },
    {
      icon: UserCheck,
      value: counters.professionals,
      suffix: '+',
      label: 'Profissionais',
    },
    {
      icon: Clock,
      value: counters.hours,
      suffix: '/7',
      label: 'Monitoramento',
    },
  ];

  return (
    <section
      ref={sectionRef}
      className="py-20 bg-dark relative overflow-hidden"
    >
      {/* Background Gradient */}
      <div className="absolute inset-0">
        <div 
          className="absolute inset-0 opacity-50"
          style={{
            background: 'linear-gradient(135deg, rgba(245, 197, 24, 0.1) 0%, rgba(230, 126, 34, 0.05) 50%, rgba(245, 197, 24, 0.1) 100%)',
            backgroundSize: '200% 200%',
            animation: 'gradient-shift 8s ease infinite',
          }}
        />
      </div>

      {/* Animated Border Top */}
      <div className="absolute top-0 left-0 right-0 h-px">
        <div 
          className="h-full w-full"
          style={{
            background: 'linear-gradient(90deg, transparent, #f5c518, transparent)',
          }}
        />
      </div>

      <div className="container-custom relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={`text-center transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              {/* Icon */}
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-yellow-brand/10 mb-4">
                <stat.icon className="w-6 h-6 text-yellow-brand" />
              </div>

              {/* Value */}
              <div className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-2">
                <span className="text-gradient">{stat.value}</span>
                <span className="text-yellow-brand">{stat.suffix}</span>
              </div>

              {/* Label */}
              <div className="text-sm text-gray-400">{stat.label}</div>

              {/* Divider (not on last item) */}
              {index < stats.length - 1 && (
                <div className="hidden lg:block absolute right-0 top-1/2 -translate-y-1/2 w-px h-16 bg-white/10" />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Animated Border Bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-px">
        <div 
          className="h-full w-full"
          style={{
            background: 'linear-gradient(90deg, transparent, #f5c518, transparent)',
          }}
        />
      </div>
    </section>
  );
};

export default Stats;
